'use strict';
var _0x48470f = _0x2c6e;
(function (_0x243386, _0x2c4677) {
    var _0x226f51 = _0x2c6e,
        _0x865f08 = _0x243386();
    while (!![]) {
        try {
            var _0x12e872 = parseInt(_0x226f51(0x141)) / 0x1 * (parseInt(_0x226f51(0x17b)) / 0x2) + -parseInt(_0x226f51(0x1d0)) / 0x3 + parseInt(_0x226f51(0x144)) / 0x4 * (-parseInt(_0x226f51(0x231)) / 0x5) + parseInt(_0x226f51(0x14c)) / 0x6 * (-parseInt(_0x226f51(0x1eb)) / 0x7) + parseInt(_0x226f51(0x236)) / 0x8 + -parseInt(_0x226f51(0x13b)) / 0x9 * (-parseInt(_0x226f51(0x1db)) / 0xa) + -parseInt(_0x226f51(0x1c0)) / 0xb;
            if (_0x12e872 === _0x2c4677) break;
            else _0x865f08['push'](_0x865f08['shift']());
        } catch (_0x3cc2e8) {
            _0x865f08['push'](_0x865f08['shift']());
        }
    }
}(_0x2fd2, 0xe9ca6));

function _0x2c6e(_0x182b46, _0x23e8e0) {
    var _0x2fd260 = _0x2fd2();
    return _0x2c6e = function (_0x2c6efd, _0x4c80a4) {
        _0x2c6efd = _0x2c6efd - 0x10d;
        var _0x48f96 = _0x2fd260[_0x2c6efd];
        return _0x48f96;
    }, _0x2c6e(_0x182b46, _0x23e8e0);
}
var $$ = Dom7,
    app = new Framework7({
        'el': _0x48470f(0x193),
        'name': _0x48470f(0x15e),
        'theme': 'ios',
        'iosTranslucentBars': ![],
        'iosTranslucentModals': ![],
        'view': {
            'browserHistory': ![]
        },
        'routes': [{
            'path': '/action-sheet/',
            'url': _0x48470f(0x183)
        }, {
            'path': '/columns/',
            'url': _0x48470f(0x235)
        }, {
            'path': _0x48470f(0x1dd),
            'url': _0x48470f(0x174)
        }, {
            'path': _0x48470f(0x110),
            'url': _0x48470f(0x13a)
        }, {
            'path': _0x48470f(0x228),
            'url': _0x48470f(0x210)
        }, {
            'path': _0x48470f(0x215),
            'url': _0x48470f(0x12c)
        }, {
            'path': _0x48470f(0x216),
            'url': _0x48470f(0x156)
        }, {
            'path': '/panel/',
            'url': _0x48470f(0x1a9)
        }, {
            'path': _0x48470f(0x199),
            'url': _0x48470f(0x16d)
        }, {
            'path': _0x48470f(0x118),
            'url': _0x48470f(0x127)
        }, {
            'path': _0x48470f(0x14b),
            'url': 'pages/features/popup.html'
        }, {
            'path': '/pull-to-refresh/',
            'url': 'pages/features/pull-to-refresh.html'
        }, {
            'path': _0x48470f(0x1d9),
            'url': 'pages/features/sheet-modal.html'
        }, {
            'path': _0x48470f(0x11b),
            'url': _0x48470f(0x123)
        }, {
            'path': _0x48470f(0x1c4),
            'url': _0x48470f(0x196)
        }, {
            'path': _0x48470f(0x155),
            'url': 'pages/features/text-editor.html'
        }, {
            'path': _0x48470f(0x208),
            'url': 'pages/features/toast.html'
        }, {
            'path': _0x48470f(0x20b),
            'url': 'pages/features/tooltip.html'
        }, {
            'path': _0x48470f(0x150),
            'url': _0x48470f(0x132)
        }, {
            'path': '/accordion/',
            'url': _0x48470f(0x182)
        }, {
            'path': _0x48470f(0x1a8),
            'url': _0x48470f(0x111)
        }, {
            'path': '/author-list/',
            'url': _0x48470f(0x154)
        }, {
            'path': _0x48470f(0x211),
            'url': _0x48470f(0x116)
        }, {
            'path': _0x48470f(0x1a0),
            'url': _0x48470f(0x1d6)
        }, {
            'path': _0x48470f(0x1be),
            'url': _0x48470f(0x1d2)
        }, {
            'path': _0x48470f(0x124),
            'url': _0x48470f(0x1a4)
        }, {
            'path': '/card-footer/',
            'url': _0x48470f(0x15b)
        }, {
            'path': _0x48470f(0x119),
            'url': _0x48470f(0x18d)
        }, {
            'path': '/comments/',
            'url': 'pages/components/comments.html'
        }, {
            'path': '/event-list/',
            'url': _0x48470f(0x218)
        }, {
            'path': '/history-timeline/',
            'url': 'pages/components/history-timeline.html'
        }, {
            'path': _0x48470f(0x17c),
            'url': _0x48470f(0x16e)
        }, {
            'path': _0x48470f(0x190),
            'url': _0x48470f(0x161)
        }, {
            'path': _0x48470f(0x21e),
            'url': _0x48470f(0x17a)
        }, {
            'path': _0x48470f(0x134),
            'url': _0x48470f(0x1a5)
        }, {
            'path': '/picker/',
            'url': _0x48470f(0x1fe)
        }, {
            'path': _0x48470f(0x1ee),
            'url': _0x48470f(0x173)
        }, {
            'path': _0x48470f(0x1a6),
            'url': 'pages/components/preloader.html'
        }, {
            'path': '/progress-bar/',
            'url': _0x48470f(0x1ca)
        }, {
            'path': _0x48470f(0x1b5),
            'url': _0x48470f(0x1d8)
        }, {
            'path': _0x48470f(0x140),
            'url': _0x48470f(0x1f8)
        }, {
            'path': _0x48470f(0x1e1),
            'url': _0x48470f(0x237)
        }, {
            'path': '/slider-cards/',
            'url': _0x48470f(0x147)
        }, {
            'path': '/slider-cards-footer/',
            'url': _0x48470f(0x1e4)
        }, {
            'path': _0x48470f(0x115),
            'url': _0x48470f(0x14f)
        }, {
            'path': '/slider-authors/',
            'url': _0x48470f(0x1c1)
        }, {
            'path': _0x48470f(0x1c2),
            'url': 'pages/components/slider-albums.html'
        }, {
            'path': _0x48470f(0x1ed),
            'url': _0x48470f(0x187)
        }, {
            'path': _0x48470f(0x172),
            'url': _0x48470f(0x1ac)
        }, {
            'path': _0x48470f(0x14d),
            'url': _0x48470f(0x120)
        }, {
            'path': _0x48470f(0x207),
            'url': _0x48470f(0x10d)
        }, {
            'path': _0x48470f(0x146),
            'url': _0x48470f(0x1e8)
        }, {
            'path': _0x48470f(0x213),
            'url': 'pages/components/toggle-button.html'
        }, {
            'path': _0x48470f(0x20e),
            'url': 'pages/pages/signup.html'
        }, {
            'path': _0x48470f(0x16b),
            'url': _0x48470f(0x21c)
        }, {
            'path': _0x48470f(0x1fc),
            'url': _0x48470f(0x1ae)
        }, {
            'path': _0x48470f(0x131),
            'url': _0x48470f(0x22c)
        }, {
            'path': _0x48470f(0x142),
            'url': _0x48470f(0x224)
        }, {
            'path': _0x48470f(0x226),
            'url': 'pages/pages/single.html'
        }, {
            'path': _0x48470f(0x234),
            'url': _0x48470f(0x232)
        }, {
            'path': _0x48470f(0x18e),
            'url': _0x48470f(0x135)
        }, {
            'path': _0x48470f(0x1de),
            'url': _0x48470f(0x130)
        }, {
            'path': _0x48470f(0x1ff),
            'url': _0x48470f(0x21d)
        }, {
            'path': '/help-center/',
            'url': _0x48470f(0x139)
        }, {
            'path': _0x48470f(0x168),
            'url': _0x48470f(0x1ba)
        }, {
            'path': _0x48470f(0x17d),
            'url': _0x48470f(0x1b4)
        }, {
            'path': _0x48470f(0x13e),
            'url': _0x48470f(0x20f)
        }, {
            'path': _0x48470f(0x1fd),
            'url': 'pages/pages/profile.html'
        }, {
            'path': _0x48470f(0x1d7),
            'url': 'pages/pages/search.html'
        }, {
            'path': '/notifications/',
            'url': _0x48470f(0x129)
        }, {
            'path': _0x48470f(0x181),
            'url': _0x48470f(0x10e),
            'options': {
                'transition': _0x48470f(0x1a7)
            }
        }]
    });
$$(document)['on'](_0x48470f(0x12e), _0x48470f(0x202), function (_0x50b3c3) {
    var _0x11951a = _0x48470f;
    $$('.open-alert')['on']('click', function () {
        var _0x1ee06a = _0x2c6e;
        app['dialog'][_0x1ee06a(0x1f3)](_0x1ee06a(0x186));
    }), $$(_0x11951a(0x219))['on'](_0x11951a(0x167), function () {
        var _0x5ee86d = _0x11951a;
        app['dialog'][_0x5ee86d(0x201)](_0x5ee86d(0x176), function () {
            var _0x46db7d = _0x5ee86d;
            app[_0x46db7d(0x21a)][_0x46db7d(0x1f3)](_0x46db7d(0x1b3));
        });
    });
}), $$(document)['on'](_0x48470f(0x12e), _0x48470f(0x143), function (_0xda05e3) {
    var _0x4db195 = _0x48470f,
        _0x11ba51 = !![],
        _0x4a1d2a = $$('.infinite-scroll-demo .post-horizontal')['length'],
        _0x105865 = 0x1e,
        _0x31f179 = 0x5;
    $$(_0x4db195(0x1ad))['on']('infinite', function () {
        if (!_0x11ba51) return;
        _0x11ba51 = ![], setTimeout(function () {
            var _0x22987e = _0x2c6e;
            _0x11ba51 = !![];
            if (_0x4a1d2a >= _0x105865) {
                app[_0x22987e(0x1bb)][_0x22987e(0x1f4)](_0x22987e(0x1ad)), $$(_0x22987e(0x21f))[_0x22987e(0x204)]();
                return;
            }
            var _0x252987 = '';
            for (var _0xf3a5a = _0x4a1d2a + 0x1; _0xf3a5a <= _0x4a1d2a + _0x31f179; _0xf3a5a++) {
                _0x252987 += _0x22987e(0x222) + _0x22987e(0x11e) + _0x22987e(0x1e5) + _0x22987e(0x1b1) + '<div class=\"post-date\">2 hours ago</div>' + _0x22987e(0x229) + _0x22987e(0x205) + (_0xf3a5a + 0x1) + _0x22987e(0x229) + _0x22987e(0x184);
            }
            $$(_0x22987e(0x1b2))['append'](_0x252987), _0x4a1d2a = $$(_0x22987e(0x137))['length'];
        }, 0x7d0);
    });
}), $$(document)['on'](_0x48470f(0x12e), _0x48470f(0x19a), function (_0x115e18) {
    var _0x3e436f = _0x48470f,
        _0x2d0d48 = app[_0x3e436f(0x1ab)][_0x3e436f(0x11c)]({
            'icon': _0x3e436f(0x12d),
            'title': _0x3e436f(0x1d3),
            'subtitle': _0x3e436f(0x15f),
            'text': _0x3e436f(0x16a),
            'closeButton': !![]
        });
    $$('.open-notification')['on'](_0x3e436f(0x167), function () {
        _0x2d0d48['open']();
    });
}), $$(document)['on'](_0x48470f(0x12e), _0x48470f(0x238), function (_0x55165d) {
    var _0x11c736 = _0x48470f,
        _0x42102f = app[_0x11c736(0x1cb)][_0x11c736(0x11c)]({
            'photos': [_0x11c736(0x16c), 'img/images/2.jpg', _0x11c736(0x1b9), _0x11c736(0x171), 'img/images/5.jpg'],
            'theme': 'dark'
        });
    $$(_0x11c736(0x1f1))['on'](_0x11c736(0x167), function () {
        var _0x1ddbc5 = _0x11c736;
        _0x42102f[_0x1ddbc5(0x1d4)]();
    });
}), $$(document)['on']('page:init', _0x48470f(0x1bf), function (_0x52acf1) {
    var _0x2303e0 = _0x48470f,
        _0x4723a1 = app[_0x2303e0(0x13d)][_0x2303e0(0x11c)]({
            'inputEl': _0x2303e0(0x209),
            'cols': [{
                'textAlign': 'center',
                'values': ['Spanish', _0x2303e0(0x1bd), _0x2303e0(0x1c5), _0x2303e0(0x1f7), _0x2303e0(0x1a1), _0x2303e0(0x1c6), _0x2303e0(0x22d), _0x2303e0(0x11f)]
            }]
        }),
        _0xb60b0b = app['picker']['create']({
            'inputEl': _0x2303e0(0x185),
            'cols': [{
                'textAlign': _0x2303e0(0x19f),
                'values': [_0x2303e0(0x191), _0x2303e0(0x1cf), _0x2303e0(0x1b6), _0x2303e0(0x214), 'May', _0x2303e0(0x1bc), _0x2303e0(0x13c), _0x2303e0(0x14e), _0x2303e0(0x1ea), _0x2303e0(0x159), _0x2303e0(0x1b8), _0x2303e0(0x1a2)]
            }]
        }),
        _0x192c12 = app[_0x2303e0(0x13d)]['create']({
            'inputEl': _0x2303e0(0x1a3),
            'cols': [{
                'textAlign': _0x2303e0(0x19f),
                'values': ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31']
            }]
        }),
        _0x2c605d = app[_0x2303e0(0x13d)][_0x2303e0(0x11c)]({
            'inputEl': _0x2303e0(0x14a),
            'cols': [{
                'textAlign': _0x2303e0(0x19f),
                'values': [_0x2303e0(0x165), '1984', '1985', '1986', _0x2303e0(0x125), '1988', _0x2303e0(0x178), _0x2303e0(0x203), '1991', _0x2303e0(0x1ec), '1993', _0x2303e0(0x1e9), _0x2303e0(0x113), _0x2303e0(0x22e), _0x2303e0(0x1b0), _0x2303e0(0x1e3), _0x2303e0(0x114), _0x2303e0(0x1cd), _0x2303e0(0x18f), '2002', _0x2303e0(0x12b), '2004', '2005']
            }]
        });
}), $$(document)['on'](_0x48470f(0x12e), '.page[data-name=\"preloader\"]', function (_0x271e31) {
    var _0x533f74 = _0x48470f;
    $$(_0x533f74(0x233))['on'](_0x533f74(0x167), function () {
        var _0x174da5 = _0x533f74;
        app['preloader'][_0x174da5(0x12a)](), setTimeout(function () {
            app['preloader']['hide']();
        }, 0x7d0);
    });
}), $$(document)['on'](_0x48470f(0x12e), _0x48470f(0x11d), function (_0x24aa4d) {
    var _0x4e089e = _0x48470f,
        _0x743b13 = $$(_0x4e089e(0x17f));
    _0x743b13['on']('ptr:refresh', function (_0x36fa91) {
        setTimeout(function () {
            var _0x2b07f8 = _0x2c6e,
                _0x485bb1 = '<a href=\"/single/\" class=\"link post-horizontal\">' + '<div class=\"infos\">' + '<div class=\"post-category\">Fashion</div>' + _0x2b07f8(0x1b1) + _0x2b07f8(0x15d) + _0x2b07f8(0x229) + _0x2b07f8(0x1c7) + _0x2b07f8(0x184);
            _0x743b13[_0x2b07f8(0x189)](_0x2b07f8(0x13f))[_0x2b07f8(0x19e)](_0x485bb1), app[_0x2b07f8(0x160)][_0x2b07f8(0x223)]();
        }, 0x7d0);
    });
}), $$(document)['on']('page:init', _0x48470f(0x152), function (_0x9ba6c2) {
    var _0x2ae583 = _0x48470f;
    $$(_0x2ae583(0x18b))['on']('range:change', function (_0x2460e4, _0xe13801) {
        var _0x52a999 = _0x2ae583;
        $$(_0x52a999(0x1e2))[_0x52a999(0x149)](_0xe13801[0x0] + ' - ' + _0xe13801[0x1]);
    }), $$(_0x2ae583(0x12f))['on'](_0x2ae583(0x1b7), function (_0x835812, _0x3daf4a) {
        var _0x5d2a30 = _0x2ae583;
        $$(_0x5d2a30(0x1f6))[_0x5d2a30(0x149)]('$' + _0x3daf4a[0x0] + _0x5d2a30(0x1da) + _0x3daf4a[0x1]);
    });
}), $$(document)['on'](_0x48470f(0x12e), _0x48470f(0x1ce), function (_0x370a41) {
    var _0x4c69e5 = _0x48470f,
        _0x351644 = app[_0x4c69e5(0x138)][_0x4c69e5(0x11c)]({
            'text': _0x4c69e5(0x198),
            'closeTimeout': 0x7d0
        });
    $$(_0x4c69e5(0x158))['on'](_0x4c69e5(0x167), function () {
        var _0x4c3a7b = _0x4c69e5;
        _0x351644[_0x4c3a7b(0x1d4)]();
    });
    var _0x399485 = app['toast'][_0x4c69e5(0x11c)]({
        'text': _0x4c69e5(0x198),
        'position': _0x4c69e5(0x230),
        'closeTimeout': 0x7d0
    });
    $$('.open-toast-top')['on'](_0x4c69e5(0x167), function () {
        var _0x5a73c7 = _0x4c69e5;
        _0x399485[_0x5a73c7(0x1d4)]();
    });
    var _0x38d019 = app[_0x4c69e5(0x138)][_0x4c69e5(0x11c)]({
        'text': _0x4c69e5(0x198),
        'position': _0x4c69e5(0x19f),
        'closeTimeout': 0x7d0
    });
    $$(_0x4c69e5(0x117))['on']('click', function () {
        var _0x544494 = _0x4c69e5;
        _0x38d019[_0x544494(0x1d4)]();
    });
    var _0x302920 = app[_0x4c69e5(0x138)][_0x4c69e5(0x11c)]({
        'text': _0x4c69e5(0x198),
        'closeButton': !![]
    });
    $$('.open-toast-button')['on'](_0x4c69e5(0x167), function () {
        var _0x40e2a6 = _0x4c69e5;
        _0x302920[_0x40e2a6(0x1d4)]();
    });
}), $$(document)['on'](_0x48470f(0x12e), '.page[data-name=\"chat\"]', function (_0x5f029c) {
    var _0x48781e = _0x48470f,
        _0x4821f2 = app['messages']['create']({
            'el': '.messages',
            'firstMessageRule': function (_0x72a019, _0x56c781, _0x5a9de1) {
                var _0x37da5d = _0x2c6e;
                if (_0x72a019[_0x37da5d(0x1fb)]) return ![];
                if (!_0x56c781 || _0x56c781['type'] !== _0x72a019[_0x37da5d(0x21b)] || _0x56c781[_0x37da5d(0x1c3)] !== _0x72a019[_0x37da5d(0x1c3)]) return !![];
                return ![];
            },
            'lastMessageRule': function (_0x232ec8, _0x16f4f8, _0x393dc5) {
                var _0xa77add = _0x2c6e;
                if (_0x232ec8[_0xa77add(0x1fb)]) return ![];
                if (!_0x393dc5 || _0x393dc5[_0xa77add(0x21b)] !== _0x232ec8[_0xa77add(0x21b)] || _0x393dc5[_0xa77add(0x1c3)] !== _0x232ec8[_0xa77add(0x1c3)]) return !![];
                return ![];
            }
        }),
        _0x56d549 = app[_0x48781e(0x1af)][_0x48781e(0x11c)]({
            'el': _0x48781e(0x18c)
        }),
        _0x4cb16d = ![];
    $$(_0x48781e(0x175))['on'](_0x48781e(0x167), function () {
        var _0x48021a = _0x48781e,
            _0xaca53f = _0x56d549[_0x48021a(0x169)]()['replace'](/\n/g, _0x48021a(0x197))[_0x48021a(0x194)]();
        if (!_0xaca53f['length']) return;
        _0x56d549[_0x48021a(0x1aa)](), _0x56d549['focus'](), _0x4821f2[_0x48021a(0x163)]({
            'text': _0xaca53f
        });
        if (_0x4cb16d) return;
        _0xb815b3();
    });

    function _0xb815b3() {
        _0x4cb16d = !![], setTimeout(function () {
            var _0x13be68 = _0x2c6e;
            _0x4821f2[_0x13be68(0x1fa)]({
                'header': _0x13be68(0x20d),
                'avatar': _0x13be68(0x19d)
            }), setTimeout(function () {
                var _0x35fa5d = _0x13be68;
                _0x4821f2[_0x35fa5d(0x163)]({
                    'text': _0x35fa5d(0x188),
                    'type': 'received',
                    'avatar': _0x35fa5d(0x19d)
                }), _0x4821f2[_0x35fa5d(0x19c)](), _0x4cb16d = ![];
            }, 0x7d0);
        }, 0x1f4);
    }
}), $$(document)['on'](_0x48470f(0x12e), '.page[data-name=\"calendar\"]', function (_0x18c5cb) {
    var _0x2d2a72 = _0x48470f,
        _0x4f4410 = ['January', _0x2d2a72(0x1cf), 'March', 'April', _0x2d2a72(0x1c9), 'June', 'July', _0x2d2a72(0x14e), _0x2d2a72(0x1ea), 'October', _0x2d2a72(0x1b8), _0x2d2a72(0x1a2)],
        _0x164262 = app[_0x2d2a72(0x122)][_0x2d2a72(0x11c)]({
            'containerEl': '#calendar',
            'value': [new Date()],
            'weekHeader': ![],
            'renderToolbar': function () {
                var _0x43bd88 = _0x2d2a72;
                return _0x43bd88(0x15a) + _0x43bd88(0x18a) + _0x43bd88(0x22f) + '<a href=\"#\" class=\"link icon-only\"><i class=\"icon icon-back ' + (app[_0x43bd88(0x153)] === 'md' ? _0x43bd88(0x145) : '') + _0x43bd88(0x10f) + _0x43bd88(0x229) + _0x43bd88(0x133) + _0x43bd88(0x22b) + _0x43bd88(0x177) + (app[_0x43bd88(0x153)] === 'md' ? _0x43bd88(0x145) : '') + '\"></i></a>' + _0x43bd88(0x229) + _0x43bd88(0x229) + '</div>';
            },
            'on': {
                'init': function (_0x4802a4) {
                    var _0x29506a = _0x2d2a72;
                    $$('.calendar-custom-toolbar .center')[_0x29506a(0x149)](_0x4f4410[_0x4802a4[_0x29506a(0x121)]] + ', ' + _0x4802a4[_0x29506a(0x195)]), $$(_0x29506a(0x11a))['on']('click', function () {
                        var _0x5866c6 = _0x29506a;
                        _0x164262[_0x5866c6(0x217)]();
                    }), $$(_0x29506a(0x1f0))['on'](_0x29506a(0x167), function () {
                        var _0x590f17 = _0x29506a;
                        _0x164262[_0x590f17(0x1cc)]();
                    });
                },
                'monthYearChangeStart': function (_0x1c8ee3) {
                    var _0x36eb56 = _0x2d2a72;
                    $$(_0x36eb56(0x1e7))[_0x36eb56(0x149)](_0x4f4410[_0x1c8ee3[_0x36eb56(0x121)]] + ', ' + _0x1c8ee3[_0x36eb56(0x195)]);
                }
            }
        });
}), $$(document)['on'](_0x48470f(0x12e), _0x48470f(0x1e0), function (_0x48ef5b) {
    var _0x505faf = _0x48470f;
    const _0x41c277 = document[_0x505faf(0x180)](_0x505faf(0x162));
    $$(_0x505faf(0x19b))['on'](_0x505faf(0x167), () => {
        var _0x4ff1c3 = _0x505faf;
        const _0x5e54f3 = _0x41c277[_0x4ff1c3(0x221)][_0x4ff1c3(0x1dc)]['length'],
            _0x384c2d = _0x41c277['swiper'][_0x4ff1c3(0x112)] + 0x1;
        console['log'](_0x384c2d + ' / ' + _0x5e54f3);
        if (_0x384c2d == _0x5e54f3) {
            app[_0x4ff1c3(0x192)][_0x4ff1c3(0x17e)]['router'][_0x4ff1c3(0x20a)]();
            return;
        }
        _0x41c277[_0x4ff1c3(0x221)][_0x4ff1c3(0x1f9)](), _0x384c2d == _0x5e54f3 - 0x1 && $$('.onboarding-next-button')['text'](_0x4ff1c3(0x1ef));
    });
}), $$(_0x48470f(0x151))['on'](_0x48470f(0x167), function () {
    var _0x280903 = _0x48470f;
    app[_0x280903(0x192)][_0x280903(0x17e)]['router'][_0x280903(0x179)]($$(this)[_0x280903(0x136)](_0x280903(0x20c)));
}), $$(document)['on'](_0x48470f(0x12e), function (_0xfa8f89) {
    var _0xa35903 = _0x48470f;
    $$(_0xa35903(0x151))['on']('click', function () {
        var _0x3be816 = _0xa35903;
        app[_0x3be816(0x192)][_0x3be816(0x17e)][_0x3be816(0x220)][_0x3be816(0x179)]($$(this)[_0x3be816(0x136)](_0x3be816(0x20c)));
    });
}), $$(_0x48470f(0x148))['on'](_0x48470f(0x167), function () {
    var _0x35e2db = _0x48470f;
    $$(_0x35e2db(0x225))[_0x35e2db(0x1f5)](_0x35e2db(0x1e6)) ? $$('.switch-theme i')[_0x35e2db(0x149)]('moon_stars') : $$('.switch-theme i')[_0x35e2db(0x149)]('sun_max'), $$(_0x35e2db(0x225))[_0x35e2db(0x1d5)]('dark');
});



function _0x2fd2() {
    var _0x23af3a = ['toggleClass', 'pages/components/button.html', '/search/', 'pages/components/radio.html', '/sheet-modal/', ' - $', '630UEfZdM', 'slides', '/dialog/', '/album/', 'url', '.page[data-name=\"onboarding\"]', '/rating/', '.age-value', '1998', 'pages/components/slider-cards-footer.html', '<div class=\"post-category\">Fashion</div>', 'dark', '.calendar-custom-toolbar .center', 'pages/components/ticket.html', '1994', 'September', '69671DkEZXo', '1992', '/slider-movies/', '/post-list/', 'Start!', '.calendar-custom-toolbar .right .link', '.photo-browser-demo', 'push', 'alert', 'destroy', 'hasClass', '.price-value', 'Hindi', 'pages/components/range-slider.html', 'slideNext', 'showTyping', 'isTitle', '/forgot-password/', '/profile/', 'pages/components/picker.html', '/calendar/', 'then', 'confirm', '.page[data-name=\"dialog\"]', '1990', 'remove', '<div class=\"post-image\">', 'location', '/text-input/', '/toast/', '#demo-picker-language', 'back', '/tooltip/', 'data-href', 'Jack is typing...', '/signup/', 'pages/pages/categories.html', 'pages/features/infinite-scroll.html', '/badge/', 'xhr', '/toggle-button/', 'April', '/notification/', '/page/', 'prevMonth', 'pages/components/event-list.html', '.open-confirm', 'dialog', 'type', 'pages/pages/signin.html', 'pages/pages/calendar.html', '/list/', '.infinite-scroll-preloader', 'router', 'swiper', '<a href=\"/single/\" class=\"link post-horizontal\">', 'done', 'pages/pages/chat.html', 'body', '/single/', 'switchTheme', '/infinite-scroll/', '</div>', 'now', '<div class=\"right\">', 'pages/pages/messages.html', 'Japanese', '1996', '<div class=\"left\">', 'top', '40SIamkb', 'pages/pages/create-post.html', '.open-preloader', '/create-post/', 'pages/features/columns.html', '8970704kSgsJy', 'pages/components/rating.html', '.page[data-name=\"photo-browser\"]', 'pages/components/text-input.html', 'pages/pages/onboarding.html', '\"></i></a>', '/icons/', 'pages/components/album-list.html', 'activeIndex', '1995', '1999', '/slider-categories/', 'pages/components/badge.html', '.open-toast-center', '/popover/', '/card-big-footer/', '.calendar-custom-toolbar .left .link', '/swipe-to-delete/', 'create', '.page[data-name=\"pull-to-refresh\"]', '<div class=\"infos\">', 'German', 'pages/components/stocks.html', 'currentMonth', 'calendar', 'pages/features/swipe-to-delete.html', '/card/', '1987', 'switchBackdrop', 'pages/features/popover.html', 'origin', 'pages/pages/notifications.html', 'show', '2003', 'pages/features/notification.html', '<img src=\"img/avatars/small-avatar.jpg\" alt=\"\" class=\"notification-image\" />', 'page:init', '#price-filter', 'pages/pages/album.html', '/messages/', 'pages/features/typography.html', '<div class=\"center\"></div>', '/list-icon/', 'pages/pages/movie.html', 'attr', '.infinite-scroll-demo .post-horizontal', 'toast', 'pages/pages/help-center.html', 'pages/features/icons.html', '146925VGqvQX', 'July', 'picker', '/categories/', '.post-list', '/range-slider/', '643yNoAjb', '/chat/', '.page[data-name=\"infinite-scroll\"]', '98468HGRgmh', 'color-black', '/ticket/', 'pages/components/slider-cards.html', '.switch-theme', 'text', '#demo-picker-year', '/popup/', '18rvFvAY', '/stocks/', 'August', 'pages/components/slider-categories.html', '/typography/', 'swiper-slide a', '.page[data-name=\"range-slider\"]', 'theme', 'pages/components/author-list.html', '/text-editor/', 'pages/features/page.html', 'photobrowser:open photobrowser:close', '.open-toast-bottom', 'October', '<div class=\"toolbar calendar-custom-toolbar no-shadow\">', 'pages/components/card-footer.html', 'map', '<div class=\"post-date\">2 hours ago</div>', 'Yui', 'Noah Campbell has started following you!', 'ptr', 'pages/components/link-banner.html', '.swiper-onboarding', 'addMessage', 'catch', '1983', 'actions:open actions:close dialog:open dialog:close popover:open popover:close', 'click', '/contact/', 'getValue', 'Follow him back to expand your network!', '/signin/', 'img/images/1.jpg', 'pages/features/photo-browser.html', 'pages/components/information-block.html', 'error', 'postMessage', 'img/images/4.jpg', '/stepper/', 'pages/components/post-list.html', 'pages/features/dialog.html', '.send-link', 'Confirm your subscription?', '<a href=\"#\" class=\"link icon-only\"><i class=\"icon icon-forward ', '1989', 'navigate', 'pages/components/list.html', '3908nsVbzq', '/information-block/', '/settings/', 'current', '.ptr-content', 'querySelector', '/onboarding/', 'pages/components/accordion.html', 'pages/features/action-sheet.html', '</a>', '#demo-picker-month', 'Your subscription has been confirmed.', 'pages/components/slider-movies.html', 'Amazing!!!', 'find', '<div class=\"toolbar-inner\">', '#age-filter', '.messagebar', 'pages/components/card-big-footer.html', '/movie/', '2001', '/link-banner/', 'January', 'views', '#app', 'trim', 'currentYear', 'pages/features/tabs.html', '<br>', 'Thank you for your subscription!', '/photo-browser/', '.page[data-name=\"notifications\"]', '.onboarding-next-button', 'hideTyping', '../img/avatars/5.jpg', 'prepend', 'center', '/button/', 'Portuguese', 'December', '#demo-picker-day', 'pages/components/card.html', 'pages/components/list-icon.html', '/preloader/', 'f7-dive', '/album-list/', 'pages/features/panel.html', 'clear', 'notification', 'pages/components/stepper.html', '.infinite-scroll-content', 'pages/pages/forgot-password.html', 'messagebar', '1997', '<div class=\"post-title\">The Importance of Supporting Local and Independent Fashion Brands</div>', '.infinite-scroll-demo', 'Confirmed!', 'pages/pages/settings.html', '/radio/', 'March', 'range:change', 'November', 'img/images/3.jpg', 'pages/pages/contact.html', 'infiniteScroll', 'June', 'English', '/checkbox/', '.page[data-name=\"picker\"]', '6538290KxMFNZ', 'pages/components/slider-authors.html', '/slider-albums/', 'name', '/tabs/', 'Arabic', 'Russian', '<div class=\"post-image\">NEW</div>', 'parent', 'May', 'pages/components/progress-bar.html', 'photoBrowser', 'nextMonth', '2000', '.page[data-name=\"toasts\"]', 'February', '4882332VMjKeQ', 'routes', 'pages/components/checkbox.html', 'Yui Mobile', 'open'];
    _0x2fd2 = function () {
        return _0x23af3a;
    };
    return _0x2fd2();

   
}

// Call the function once to get the array of strings
var decodedArray = _0x2fd2();

// Now, you can index into `decodedArray` to see the values:
console.log(decodedArray[0]); // 'toggleClass'
console.log(decodedArray[1]); // 'pages/components/button.html'
// and so on...


